---
name: Honey remembers
details: Across sessions
status: active
---

# Honey remembers

Every ex and every breakthrough, kept in Neon.
