---
name: 05-meet-honey (shortcut)
details: points to flexos/apps/web/brief/02-pages/05-meet-honey
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/02-pages/05-meet-honey`
