---
name: Onboarding flow (shortcut)
details: points to flexos/apps/web/brief/04-flows/01-onboarding
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/04-flows/01-onboarding`
