---
name: Otp.dev
details: Phone verification
status: active
---

# How we use it

Verify phone numbers by SMS at sign-up.
