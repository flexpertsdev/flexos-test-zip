---
name: 02-sign-up (shortcut)
details: points to flexos/apps/web/brief/02-pages/02-sign-up
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/02-pages/02-sign-up`
