---
name: Sign in with Google (shortcut)
details: points to flexos/apps/web/brief/03-features/01-sign-in-with-google
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/03-features/01-sign-in-with-google`
