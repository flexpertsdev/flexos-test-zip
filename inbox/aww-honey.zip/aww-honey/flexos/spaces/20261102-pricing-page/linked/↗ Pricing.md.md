---
name: Pricing.md (shortcut)
details: points to flexos/docs/01-project/03-pricing.md
---

↗ This is a shortcut. The real folder is:

`flexos/docs/01-project/03-pricing.md`
