---
name: Pricing
details: Free, Pro, Premium
status: active
---

# Pricing

| Plan | Price |
|---|---|
| Free | $0 · 50 messages |
| Pro | $9.99 |
| Premium | $19.99 |
