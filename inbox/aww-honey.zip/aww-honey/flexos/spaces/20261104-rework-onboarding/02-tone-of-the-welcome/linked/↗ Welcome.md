---
name: Welcome (shortcut)
details: points to flexos/apps/web/brief/02-pages/01-welcome
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/02-pages/01-welcome`
