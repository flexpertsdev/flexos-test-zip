---
name: 04-what-brings-you (shortcut)
details: points to flexos/apps/web/brief/02-pages/04-what-brings-you
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/02-pages/04-what-brings-you`
