# aww honey

The project's repo, as FlexOS keeps it (a fake, for looking at in a file browser).

- `flexos/` is the brain (normally `.flexos/`, hidden; visible here so you can browse it):
  - `docs/` the Library, numbered topic folders
  - `apps/web/` everything about the website: its brief (design, pages, features, flows, data, connections)
  - `spaces/` one folder per conversation; a space's topics are its subfolders; **Linked** holds shortcuts (aliases) to the things it works on, which live where they belong
  - `connections/` one folder per service
  - `inbox/` mail that came in
- `flexboxes/web/` the website's code

Shortcuts are symbolic links (`→`). Where your file browser can't follow them, the `↗ … .md` file beside each one says where it points.
