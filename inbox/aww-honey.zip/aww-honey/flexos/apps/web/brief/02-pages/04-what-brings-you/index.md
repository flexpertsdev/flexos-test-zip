---
name: What brings you here
details: /why
path: /why
status: active
---

# What brings you here

**Path:** `/why`

## What it shows
What the person sees at this step, and the one thing they do.
