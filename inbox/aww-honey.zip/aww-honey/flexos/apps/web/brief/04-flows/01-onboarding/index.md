---
name: Onboarding flow
details: 6 steps
status: active
---

# Onboarding

Welcome → Sign up → Your name → What brings you here → Meet Honey → First chat.

## Decided
- Honey speaks before any field
