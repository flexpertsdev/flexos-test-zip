---
name: Honey's voice.md (shortcut)
details: points to flexos/docs/02-brand/02-honeys-voice.md
---

↗ This is a shortcut. The real folder is:

`flexos/docs/02-brand/02-honeys-voice.md`
