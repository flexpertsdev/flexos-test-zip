---
name: Your name
details: /name
path: /name
status: active
---

# Your name

**Path:** `/name`

## What it shows
What the person sees at this step, and the one thing they do.
