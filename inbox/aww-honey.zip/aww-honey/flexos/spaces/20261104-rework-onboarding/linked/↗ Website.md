---
name: Website (shortcut)
details: points to flexos/apps/web
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web`
