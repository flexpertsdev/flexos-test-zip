---
name: Sign up
details: /signup
path: /signup
status: active
---

# Sign up

**Path:** `/signup`

## What it shows
What the person sees at this step, and the one thing they do.
