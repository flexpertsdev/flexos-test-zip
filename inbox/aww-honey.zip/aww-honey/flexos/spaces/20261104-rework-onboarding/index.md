---
name: Rework onboarding
details: Feels like a form, should feel like a friend
related: [.flexos/apps/web/]
status: active
---

## What this is
Onboarding feels like a form. Make it feel like meeting a friend.

## Decided
- Honey speaks first
- Four screens, not six
