---
name: Design
details: Cream, a serif, peach to pink
status: active
---

# Design

Cream background, Georgia for headings, the peach→pink gradient for every main button.
