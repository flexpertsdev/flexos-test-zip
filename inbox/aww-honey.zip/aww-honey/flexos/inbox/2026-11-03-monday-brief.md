---
name: Your Monday brief: your site says 404
details: Flexi at FlexOS
status: active
---

# Your Monday brief

Your site says **404** on /roast since Saturday. One thing today: fix the roast link.
