---
name: Neon for the website
details: The database
status: active
---

# Neon

The website keeps users, chats and memories in Neon.
