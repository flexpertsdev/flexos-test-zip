---
name: Sign in with Google
details: One tap
status: active
---

# Sign in with Google

One tap on Sign up; the name comes from Google, so *Your name* can go.

**Uses:** Sign up
