---
name: Website
details: aww-honey.flexos.site
status: active
---

# Website

The web app: Honey's chat, the roast, your notes.

## Where it stands
Live. Onboarding being reworked (see the space *Rework onboarding*).
