---
name: About Neon
details: What it is
status: active
---

# About Neon

Like tidy spreadsheets your app reads and writes.
