---
name: Four screens, sketched
details: Welcome+Sign up, What brings you, Meet Honey, First chat
status: active
---

# Four screens

1. Hey you + sign up
2. What brings you here
3. Meet Honey
4. First chat (asks your name)
