---
name: Pricing page
details: Pro at $9.99
related: [.flexos/apps/web/brief/02-pages/08-pricing/, .flexos/docs/01-project/03-pricing.md]
status: active
---

## What this is
The pricing page, matched to the Library's pricing doc.
