---
name: Roast my profile
details: The viral hook
status: active
---

# Roast my profile

No sign-in needed; saving the roast asks for one.
