---
name: 03-your-name (shortcut)
details: points to flexos/apps/web/brief/02-pages/03-your-name
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/02-pages/03-your-name`
