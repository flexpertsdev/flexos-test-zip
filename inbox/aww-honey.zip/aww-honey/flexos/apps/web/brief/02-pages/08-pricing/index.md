---
name: Pricing
details: /pricing
path: /pricing
status: active
---

# Pricing

**Path:** `/pricing`

## What it shows
What the person sees at this step, and the one thing they do.
