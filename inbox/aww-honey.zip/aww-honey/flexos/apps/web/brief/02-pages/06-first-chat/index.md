---
name: First chat
details: /chat
path: /chat
status: active
---

# First chat

**Path:** `/chat`

## What it shows
What the person sees at this step, and the one thing they do.
