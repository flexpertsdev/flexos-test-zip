---
name: Tone of the welcome
details: Warmer, less clinical
related: [.flexos/apps/web/brief/02-pages/01-welcome/, .flexos/docs/02-brand/02-honeys-voice.md]
status: active
---

## What this is
The first words Honey says. Her voice, not a product's.
