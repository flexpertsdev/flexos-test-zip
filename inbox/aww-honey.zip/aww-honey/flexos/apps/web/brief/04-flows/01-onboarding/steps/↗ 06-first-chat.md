---
name: 06-first-chat (shortcut)
details: points to flexos/apps/web/brief/02-pages/06-first-chat
---

↗ This is a shortcut. The real folder is:

`flexos/apps/web/brief/02-pages/06-first-chat`
