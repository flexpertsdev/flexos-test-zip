---
name: Welcome
details: /welcome
path: /welcome
status: active
---

# Welcome

**Path:** `/welcome`

## What it shows
What the person sees at this step, and the one thing they do.
