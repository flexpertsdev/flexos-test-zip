---
name: Roast
details: /roast
path: /roast
status: active
---

# Roast

**Path:** `/roast`

## What it shows
What the person sees at this step, and the one thing they do.
