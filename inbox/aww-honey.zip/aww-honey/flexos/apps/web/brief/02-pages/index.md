---
name: Pages
details: 8 pages
status: active
---

# Pages

Every screen of the web app. Each folder: its spec (`index.md`), its drawing (`page.html`), its versions.
