---
name: Neon
details: Stores your app's data
keys: NEON_DATABASE_URL
status: active
---

# How we use it

Users, chats and memories.

# What it is
A place where your app keeps its records.
