---
name: Overview and vision
details: What Aww Honey is
status: active
---

# Overview and vision

> In short: a sassy AI therapist-friend that pairs real psychological insight with wit and radical honesty.

## For whom
Young adults and working professionals.

## What makes it different
Honey remembers, and Honey tells you the truth.
