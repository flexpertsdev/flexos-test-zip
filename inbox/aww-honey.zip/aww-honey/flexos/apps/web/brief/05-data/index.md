---
name: Data
details: Users, chats, memories
status: active
---

# Data

- **users**: email, name, plan
- **chats**: who, when, words
- **memories**: what Honey keeps
