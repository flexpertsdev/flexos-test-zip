---
name: Fewer steps
details: 6 → 4 screens
related: [.flexos/apps/web/brief/04-flows/01-onboarding/, .flexos/apps/web/brief/03-features/01-sign-in-with-google/]
status: active
---

## What this is
Six screens before anyone talks to Honey. Cut to four: Welcome and Sign up become one, Your name moves into the first chat.
