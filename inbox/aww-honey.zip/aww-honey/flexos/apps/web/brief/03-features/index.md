---
name: Features
details: 3 features
status: active
---

# Features

What the app can do, each with the pages it uses.
